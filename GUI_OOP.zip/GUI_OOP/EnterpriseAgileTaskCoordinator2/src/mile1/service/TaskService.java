package mile1.service;

import mile1.database.Database;
import mile1.entity.*;

public class TaskService {

    // ----------------------------
    // Add a Task
    // ----------------------------
    public void addTask(Task task) {
        if (task == null) {
            System.out.println("❌ Cannot add null task.");
            return;
        }

        if (taskExists(task.getTitle())) {
            System.out.println("⚠ ERROR: Task with title '" + task.getTitle() + "' already exists!");
            return;
        }

        Database.tasks.add(task);
        System.out.println("✔ Task '" + task.getTitle() + "' created successfully.");
    }

    private boolean taskExists(String title) {
        return Database.tasks.stream()
                .anyMatch(t -> t.getTitle().equalsIgnoreCase(title));
    }

    // ----------------------------
    // List all Tasks
    // ----------------------------
    public void listAllTasks() {
        if (Database.tasks.isEmpty()) {
            System.out.println("No tasks found.");
            return;
        }

        System.out.println("All tasks:");
        Database.tasks.forEach(System.out::println);
    }

    // ----------------------------
    // Get Task by Title
    // ----------------------------
    public Task getTask(String title) {
        if (title == null || title.trim().isEmpty()) return null;
        return Database.getTaskByTitle(title.trim());
    }

    // ----------------------------
    // View Task Hierarchy
    // ----------------------------
    public void viewHierarchy() {
        System.out.println("=== TASK HIERARCHY ===");

        boolean hasTasks = false;
        for (Task task : Database.tasks) {
            if (task instanceof Epic) {
                printEpicHierarchy((Epic) task);
                hasTasks = true;
            } else if (!(task instanceof Story || task instanceof SubTask)) {
                System.out.println("[Standalone] " + task.getTitle());
                hasTasks = true;
            }
        }

        if (!hasTasks) System.out.println("No tasks found.");
    }

    private void printEpicHierarchy(Epic epic) {
        String indent = "  ".repeat(0);
        System.out.println(indent + "[Epic] " + epic.getTitle());

        for (Story story : epic.getStories()) {
            System.out.println(indent + "  [Story] " + story.getTitle());
            for (SubTask subTask : story.getSubTasks()) {
                System.out.println(indent + "    [SubTask] " + subTask.getTitle());
            }
        }
    }

    public void addStoryToEpic(String epicTitle, String storyTitle) {

        if (epicTitle == null || epicTitle.trim().isEmpty()) {
            System.out.println("❌ Epic title cannot be empty.");
            return;
        }
        if (storyTitle == null || storyTitle.trim().isEmpty()) {
            System.out.println("❌ Story title cannot be empty.");
            return;
        }

        Task epicTask = getTask(epicTitle.trim());
        Task storyTask = getTask(storyTitle.trim());

        if (!(epicTask instanceof Epic epic)) {
            System.out.println("❌ ERROR: '" + epicTitle + "' is not an Epic!");
            return;
        }
        if (!(storyTask instanceof Story story)) {
            System.out.println("❌ ERROR: '" + storyTitle + "' is not a Story!");
            return;
        }

        // Optional warning if the Story is already linked to another Epic
        if (story.getEpic() != null && story.getEpic() != epic) {
            System.out.println("⚠ Story '" + story.getTitle() + "' is already linked to Epic '" +
                    story.getEpic().getTitle() + "'. It will be linked to '" + epic.getTitle() + "' now.");
        }

        epic.addStory(story); // This also sets story.setEpic(this) inside Epic.addStory(...)
    }


    public void addSubTaskToStory(String storyTitle, String subTitle) {

        if (storyTitle == null || storyTitle.trim().isEmpty()) {
            System.out.println("❌ Story title cannot be empty.");
            return;
        }
        if (subTitle == null || subTitle.trim().isEmpty()) {
            System.out.println("❌ SubTask title cannot be empty.");
            return;
        }

        Task storyTask = getTask(storyTitle.trim());
        if (!(storyTask instanceof Story story)) {
            System.out.println("❌ ERROR: '" + storyTitle + "' is not a Story!");
            return;
        }

        // Create a new SubTask and add it to the system tasks list
        SubTask subTask = new SubTask(subTitle.trim());
        addTask(subTask);           // adds to Database.tasks (with duplicate title check)
        story.addSubTask(subTask);  // links it + sets back-reference subTask.setStory(this)
    }

}
