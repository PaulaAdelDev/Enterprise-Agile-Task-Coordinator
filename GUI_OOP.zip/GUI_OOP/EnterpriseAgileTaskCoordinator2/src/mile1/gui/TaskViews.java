package mile1.gui;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import mile1.database.Database;
import mile1.entity.*;
import mile1.service.TaskService;
import mile1.service.UserService;

public class TaskViews {

    private static final TaskService taskService = new TaskService();
    private static final UserService userService = new UserService();

    // ---------------------------------------
    // Helper: standard window shell
    // ---------------------------------------
    private static Stage createWindow(String title, Pane content) {
        Stage stage = new Stage();
        stage.setTitle(title);
        stage.setScene(new Scene(content, 900, 600));
        return stage;
    }

    private static TextArea makeOutputBox() {
        TextArea output = new TextArea();
        output.setEditable(false);
        output.setWrapText(true);
        output.setPrefHeight(260);
        return output;
    }

    // ---------------------------------------
    // 1) View Tasks (calls user.viewTasks())
    // ---------------------------------------
    public static void openViewTasks(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label title = new Label("View Tasks (" + user.getRole() + ")");
        TextArea output = makeOutputBox();

        Button run = new Button("Show Tasks");
        run.setOnAction(e -> {
            String msg = OutputCapture.runAndCapture(user::viewTasks);
            output.setText(msg);
        });

        root.getChildren().addAll(title, run, output);
        createWindow("View Tasks", root).show();
    }

    // ---------------------------------------
    // 2) Create Task (matches console logic)
    // Stakeholder: Epic, Story, Bug, StandardTask
    // Developer: Bug, StandardTask
    // ---------------------------------------
    public static void openCreateTask(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label title = new Label("Create Task (" + user.getRole() + ")");
        TextField taskTitle = new TextField();
        taskTitle.setPromptText("Enter task title");

        ComboBox<String> typeBox = new ComboBox<>();
        if (user instanceof Stakeholder) {
            typeBox.getItems().addAll("Epic", "Story", "Bug", "StandardTask");
        } else if (user instanceof Developer) {
            typeBox.getItems().addAll("Bug", "StandardTask");
        } else {
            typeBox.getItems().add("No Permission");
            typeBox.setDisable(true);
        }
        typeBox.setPromptText("Select task type");

        TextArea output = makeOutputBox();

        Button create = new Button("Create");
        create.setDisable(!(user instanceof Stakeholder || user instanceof Developer));
        create.setOnAction(e -> {
            String t = taskTitle.getText().trim();
            String type = typeBox.getValue();

            String msg = OutputCapture.runAndCapture(() -> {
                if (!(user instanceof Stakeholder || user instanceof Developer)) {
                    System.out.println("❌ You don't have permission to create tasks.");
                    return;
                }

                if (type == null || type.trim().isEmpty()) {
                    System.out.println("❌ Invalid choice!");
                    return;
                }

                if (t.isEmpty()) {
                    System.out.println("❌ Task title cannot be empty!");
                    return;
                }

                // Same behavior as your console Main.createTask(...)
                if (user instanceof Stakeholder s) {
                    switch (type) {
                        case "Epic" -> s.createEpic(new Epic(t));
                        case "Story" -> s.createStory(new Story(t));
                        case "Bug" -> taskService.addTask(new Bug(t));
                        case "StandardTask" -> taskService.addTask(new StandardTask(t));
                        default -> System.out.println("❌ Invalid choice!");
                    }
                } else if (user instanceof Developer) {
                    switch (type) {
                        case "Bug" -> taskService.addTask(new Bug(t));
                        case "StandardTask" -> taskService.addTask(new StandardTask(t));
                        default -> System.out.println("❌ Invalid choice!");
                    }
                }
            });

            output.setText(msg);
        });

        root.getChildren().addAll(title, typeBox, taskTitle, create, output);
        createWindow("Create Task", root).show();
    }

    // ---------------------------------------
    // 3) Assign / Manage Task (ScrumMaster)
    // matches Main.manageTask(...)
    // ---------------------------------------
    public static void openAssignTask(ScrumMaster sm) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label title = new Label("Assign / Manage Task (ScrumMaster)");

        TextField taskTitle = new TextField();
        taskTitle.setPromptText("Enter task title");

        TextField assigneeUsername = new TextField();
        assigneeUsername.setPromptText("Enter assignee username");

        TextArea output = makeOutputBox();

        Button assign = new Button("Assign");
        assign.setOnAction(e -> {
            String tt = taskTitle.getText().trim();
            String uu = assigneeUsername.getText().trim();

            String msg = OutputCapture.runAndCapture(() -> {
                Task task = taskService.getTask(tt);
                if (task == null) {
                    System.out.println("❌ Task not found!");
                    return;
                }

                User assignee = userService.getUser(uu);
                if (assignee == null) {
                    System.out.println("❌ User not found!");
                    return;
                }

                sm.assignTask(task, assignee);
                System.out.println("✔ Task assigned successfully.");
            });

            output.setText(msg);
        });

        root.getChildren().addAll(title, taskTitle, assigneeUsername, assign, output);
        createWindow("Assign Task", root).show();
    }

    // ---------------------------------------
    // 4) Developer Actions (start/complete)
    // matches Main.developerActions(...)
    // ---------------------------------------
    public static void openDevActions(Developer dev) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label title = new Label("Developer Actions");

        TextField taskTitle = new TextField();
        taskTitle.setPromptText("Enter task title");

        ComboBox<String> action = new ComboBox<>();
        action.getItems().addAll("Start Task", "Complete Task");
        action.setPromptText("Select action");

        TextArea output = makeOutputBox();

        Button run = new Button("Run");
        run.setOnAction(e -> {
            String tt = taskTitle.getText().trim();
            String act = action.getValue();

            String msg = OutputCapture.runAndCapture(() -> {
                Task task = taskService.getTask(tt);
                if (task == null) {
                    System.out.println("❌ Task not found!");
                    return;
                }

                if (act == null) {
                    System.out.println("❌ Invalid choice!");
                    return;
                }

                if (act.equals("Start Task")) dev.startTask(task);
                else if (act.equals("Complete Task")) dev.completeTask(task);
                else System.out.println("❌ Invalid choice!");
            });

            output.setText(msg);
        });

        root.getChildren().addAll(title, taskTitle, action, run, output);
        createWindow("Developer Actions", root).show();
    }

    // ---------------------------------------
    // 5) QA Actions (test task)
    // matches Main.qaActions(...)
    // ---------------------------------------
    public static void openQaActions(QAEngineer qa) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label title = new Label("QA Actions");

        TextField taskTitle = new TextField();
        taskTitle.setPromptText("Enter task title");

        ComboBox<String> resultBox = new ComboBox<>();
        resultBox.getItems().addAll("Approved", "Rejected", "Tested");
        resultBox.setPromptText("Select QA result");

        TextArea output = makeOutputBox();

        Button run = new Button("Set QA Result");
        run.setOnAction(e -> {
            String tt = taskTitle.getText().trim();
            String rr = resultBox.getValue();

            String msg = OutputCapture.runAndCapture(() -> {
                Task task = taskService.getTask(tt);
                if (task == null) {
                    System.out.println("❌ Task not found!");
                    return;
                }

                if (rr == null || rr.trim().isEmpty()) {
                    System.out.println("❌ QA result cannot be empty!");
                    return;
                }

                qa.testTask(task, rr);
            });

            output.setText(msg);
        });

        root.getChildren().addAll(title, taskTitle, resultBox, run, output);
        createWindow("QA Actions", root).show();
    }

    // ---------------------------------------
    // 6) Break Story into SubTask (ScrumMaster)
    // matches Main.breakTaskAction(...)
    // ---------------------------------------
    public static void openBreakTask(ScrumMaster sm) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label title = new Label("Break Story into SubTask");

        TextField storyTitle = new TextField();
        storyTitle.setPromptText("Enter Story title");

        TextField subTitle = new TextField();
        subTitle.setPromptText("Enter SubTask title");

        TextArea output = makeOutputBox();

        Button run = new Button("Create + Link SubTask");
        run.setOnAction(e -> {
            String st = storyTitle.getText().trim();
            String sub = subTitle.getText().trim();

            String msg = OutputCapture.runAndCapture(() -> {
                Task t = taskService.getTask(st);
                if (!(t instanceof Story story)) {
                    System.out.println("❌ ERROR: Can only break Stories into SubTasks!");
                    return;
                }

                if (sub.isEmpty()) {
                    System.out.println("❌ SubTask title cannot be empty!");
                    return;
                }

                sm.breakTask(story, new SubTask(sub));
            });

            output.setText(msg);
        });

        root.getChildren().addAll(title, storyTitle, subTitle, run, output);
        createWindow("Break Task", root).show();
    }

    // ---------------------------------------
    // 7) Finalize Task (ScrumMaster)
    // matches Main.finalizeTaskAction(...)
    // ---------------------------------------
    public static void openFinalizeTask(ScrumMaster sm) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label title = new Label("Finalize Task (Done)");

        TextField taskTitle = new TextField();
        taskTitle.setPromptText("Enter task title to finalize");

        TextArea output = makeOutputBox();

        Button run = new Button("Finalize");
        run.setOnAction(e -> {
            String tt = taskTitle.getText().trim();

            String msg = OutputCapture.runAndCapture(() -> {
                Task task = taskService.getTask(tt);
                if (task == null) {
                    System.out.println("❌ Task not found!");
                    return;
                }

                sm.finalizeTask(task);
                System.out.println("✔ Task finalized successfully.");
            });

            output.setText(msg);
        });

        root.getChildren().addAll(title, taskTitle, run, output);
        createWindow("Finalize Task", root).show();
    }

    // ---------------------------------------
    // 8) Hierarchy Management
    // calls TaskService.addStoryToEpic / addSubTaskToStory / viewHierarchy
    // (NOTE: your service methods are currently empty, but we call them as-is)
    // ---------------------------------------
    public static void openHierarchyManagement() {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label title = new Label("Hierarchy Management");

        TextField epicTitle = new TextField();
        epicTitle.setPromptText("Epic title (for linking Story->Epic)");

        TextField storyTitle = new TextField();
        storyTitle.setPromptText("Story title");

        TextField subTitle = new TextField();
        subTitle.setPromptText("SubTask title (for linking SubTask->Story)");

        TextArea output = makeOutputBox();

        HBox buttons = new HBox(10);

        Button linkStoryToEpic = new Button("Link Story -> Epic");
        linkStoryToEpic.setOnAction(e -> {
            String msg = OutputCapture.runAndCapture(() ->
                    taskService.addStoryToEpic(epicTitle.getText().trim(), storyTitle.getText().trim())
            );
            output.setText(msg);
        });

        Button linkSubToStory = new Button("Link SubTask -> Story");
        linkSubToStory.setOnAction(e -> {
            String msg = OutputCapture.runAndCapture(() ->
                    taskService.addSubTaskToStory(storyTitle.getText().trim(), subTitle.getText().trim())
            );
            output.setText(msg);
        });

        Button viewHierarchy = new Button("View Task Hierarchy");
        viewHierarchy.setOnAction(e -> {
            String msg = OutputCapture.runAndCapture(taskService::viewHierarchy);
            output.setText(msg);
        });

        buttons.getChildren().addAll(linkStoryToEpic, linkSubToStory, viewHierarchy);

        // Optional quick view of current tasks in-memory (no modification, just display)
        Button showAllRaw = new Button("Show All Tasks (Raw List)");
        showAllRaw.setOnAction(e -> {
            String msg = OutputCapture.runAndCapture(() -> {
                if (Database.tasks.isEmpty()) {
                    System.out.println("No tasks found.");
                } else {
                    System.out.println("All tasks:");
                    Database.tasks.forEach(System.out::println);
                }
            });
            output.setText(msg);
        });

        root.getChildren().addAll(title, epicTitle, storyTitle, subTitle, buttons, showAllRaw, output);
        createWindow("Hierarchy Management", root).show();
    }
}
